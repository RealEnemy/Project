#!/usr/bin/env python3
import sys
sys.path.insert(1, '/home/kali/Desktop/project_Boychenko_B24-505/project_func')
import prompt
from cli import welcome
def main():
    welcome()

if __name__ == '__main__':
    main()
